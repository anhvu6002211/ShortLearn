"use strict";
(() => {
  // src/shared/subtitles.ts
  function parseJson3(payload) {
    if (!payload || typeof payload !== "object" || !("events" in payload) || !Array.isArray(payload.events)) return [];
    return payload.events.flatMap((event) => {
      if (!Array.isArray(event?.segs) || typeof event.tStartMs !== "number") return [];
      const text = event.segs.map((segment) => typeof segment?.utf8 === "string" ? segment.utf8 : "").join("").replace(/♪|\[[^\]]*\]/g, "").replace(/\s+/g, " ").trim();
      return text ? [{ start: event.tStartMs / 1e3, duration: (typeof event.dDurationMs === "number" ? event.dDurationMs : 2500) / 1e3, text }] : [];
    });
  }

  // src/content/youtube/captions.ts
  async function loadEnglishCues(videoId) {
    const player = document.querySelector("#movie_player, .html5-video-player");
    const response = player?.getPlayerResponse?.();
    if (response?.videoDetails?.videoId !== videoId) return [];
    const tracks = response?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    if (!Array.isArray(tracks)) return [];
    const track = tracks.find((item) => item.languageCode === "en" || item.languageCode?.startsWith("en-")) ?? tracks[0];
    if (!track?.baseUrl) return [];
    const url = new URL(track.baseUrl);
    url.searchParams.set("fmt", "json3");
    const result = await fetch(url);
    return result.ok ? parseJson3(await result.json()) : [];
  }

  // src/content/youtube/domCaptions.ts
  var CAPTION_SELECTOR = ".ytp-caption-segment";
  function cleanCaptionText(value) {
    return value.replace(/♪|\[[^\]]*\]/g, "").replace(/^\s*(?:>>\s*)+/, "").replace(/\s+/g, " ").trim();
  }
  function readVisibleCaption(root = document) {
    const parts = Array.from(root.querySelectorAll(CAPTION_SELECTOR)).filter((node) => node.getClientRects().length > 0).map((node) => cleanCaptionText(node.textContent ?? "")).filter(Boolean);
    return cleanCaptionText(parts.join(" "));
  }
  function observesCaptionMutation(record) {
    const element = record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement;
    if (element?.closest(CAPTION_SELECTOR)) return true;
    return Array.from(record.addedNodes).some(
      (node) => node.nodeType === Node.ELEMENT_NODE && (node.matches(CAPTION_SELECTOR) || Boolean(node.querySelector(CAPTION_SELECTOR)))
    );
  }

  // src/content/youtube/video.ts
  var MATCHES = ["/watch", "/shorts/"];
  function youtubeVideoId(url = location.href) {
    const parsed = new URL(url);
    const shorts = parsed.pathname.match(/^\/shorts\/([\w-]{11})/);
    if (shorts) return shorts[1];
    const watch = parsed.searchParams.get("v");
    return parsed.pathname === "/watch" && watch && /^[\w-]{11}$/.test(watch) ? watch : null;
  }
  function isSupportedYouTubePage() {
    return MATCHES.some((value) => location.pathname.startsWith(value));
  }

  // src/content/page.ts
  var SOURCE = "shortlearn-page";
  var activeId = null;
  var generation = 0;
  var scheduled = false;
  var lastText = "";
  function emit(type, payload = {}) {
    window.postMessage({ source: SOURCE, type, ...payload }, location.origin);
  }
  function emitDomCaption() {
    const text = readVisibleCaption();
    if (text && text !== lastText) {
      lastText = text;
      emit("CAPTION", { text, time: document.querySelector("video")?.currentTime ?? 0 });
    }
  }
  async function refresh() {
    const videoId = youtubeVideoId();
    if (!isSupportedYouTubePage() || !videoId) return emit("UNSUPPORTED");
    if (videoId === activeId) return;
    activeId = videoId;
    lastText = "";
    const current = ++generation;
    emit("VIDEO", { videoId });
    for (const delay of [0, 1e3, 2500]) {
      if (delay) await new Promise((resolve) => setTimeout(resolve, delay));
      const cues = await loadEnglishCues(videoId).catch(() => []);
      if (current !== generation) return;
      if (cues.length) return emit("CUES", { videoId, cues });
    }
    emit("FALLBACK", { videoId });
    emitDomCaption();
    await new Promise((resolve) => setTimeout(resolve, 5e3));
    if (current === generation && !lastText) emit("NO_CAPTION", { videoId });
  }
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      void refresh();
    });
  }
  var observer = new MutationObserver((records) => {
    if (records.some(observesCaptionMutation)) emitDomCaption();
    schedule();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("yt-navigate-finish", schedule);
  window.addEventListener("popstate", schedule);
  schedule();
})();
