// src/services/auth/index.ts
var KEY = "shortlearn.session";
async function loadSession() {
  const v = await chrome.storage.local.get([KEY]);
  return v[KEY] || null;
}
async function saveSession(session) {
  if (session) await chrome.storage.local.set({ [KEY]: session });
  else await chrome.storage.local.remove([KEY]);
}
function normalizeApiUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(url.hostname)) throw new Error("API ph\u1EA3i d\xF9ng HTTPS.");
  return url.origin;
}
async function request(apiUrl2, path, init = {}, retry = true) {
  const session = await loadSession();
  const response = await fetch(`${apiUrl2}${path}`, { ...init, headers: { "Content-Type": "application/json", ...session?.tokens.access_token ? { Authorization: `Bearer ${session.tokens.access_token}` } : {} } });
  if (response.status === 401 && retry && session?.tokens.refresh_token && !path.includes("/auth/")) {
    const refreshed = await request(apiUrl2, "/api/v1/auth/refresh", { method: "POST", body: JSON.stringify({ refresh_token: session.tokens.refresh_token }) }, false);
    await saveSession({ ...session, tokens: refreshed.tokens });
    return request(apiUrl2, path, init, false);
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i ShortLearn.");
  return payload;
}
async function login(apiUrl2, email, password) {
  const base = normalizeApiUrl(apiUrl2);
  const session = await request(base, "/api/v1/auth/login", { method: "POST", body: JSON.stringify({ email, password, device: { platform: "extension", name: navigator.userAgent.slice(0, 80), app_version: "0.1.0" } }) }, false);
  await saveSession(session);
  await chrome.storage.local.set({ "shortlearn.apiUrl": base });
  return session;
}
async function logout() {
  const s = await loadSession();
  const data = await chrome.storage.local.get(["shortlearn.apiUrl"]);
  try {
    if (s && data["shortlearn.apiUrl"]) await request(data["shortlearn.apiUrl"], "/api/v1/auth/logout", { method: "POST", body: JSON.stringify({ refresh_token: s.tokens.refresh_token }) }, false);
  } finally {
    await saveSession(null);
  }
}

// src/services/vocabulary/index.ts
async function apiUrl() {
  const data = await chrome.storage.local.get(["shortlearn.apiUrl"]);
  const api = data["shortlearn.apiUrl"];
  if (typeof api !== "string") throw new Error("H\xE3y \u0111\u0103ng nh\u1EADp ShortLearn.");
  return api;
}
async function saveWord(input) {
  return request(await apiUrl(), "/api/v1/vocabulary/save", { method: "POST", body: JSON.stringify({ word: input.word, meaning: input.meaning, context_sentence: input.context, platform: input.platform, video_id: input.videoId, timestamp_mark: input.timestamp }) });
}
async function dueCards() {
  const payload = await request(await apiUrl(), "/api/v1/vocabulary/due");
  return Array.isArray(payload.cards) ? payload.cards : [];
}
async function reviewWord(word, rating) {
  return request(await apiUrl(), "/api/v1/vocabulary/review", { method: "POST", body: JSON.stringify({ word, rating }) });
}

// src/background/index.ts
var PLATFORMS = /* @__PURE__ */ new Set(["youtube", "tiktok", "instagram"]);
var capturedTabId = null;
function bounded(value, max) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= max;
}
async function stopCapture() {
  let result = { ok: true };
  if (await chrome.offscreen.hasDocument()) {
    result = await chrome.runtime.sendMessage({ type: "CAPTURE_STOP" });
    await chrome.offscreen.closeDocument();
  }
  capturedTabId = null;
  return result;
}
chrome.runtime.onInstalled.addListener(() => console.info("ShortLearn Extension installed"));
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === capturedTabId) void stopCapture();
});
chrome.runtime.onSuspend.addListener(() => {
  void stopCapture();
});
chrome.runtime.onMessage.addListener((raw, _sender, reply) => {
  const message = raw;
  void (async () => {
    try {
      switch (message.type) {
        case "AUTH_STATUS":
          reply({ ok: true, data: await loadSession() });
          break;
        case "AUTH_LOGIN":
          if (!bounded(message.email, 254) || !bounded(message.password, 512) || !bounded(message.apiUrl, 2048)) throw new Error("D\u1EEF li\u1EC7u \u0111\u0103ng nh\u1EADp kh\xF4ng h\u1EE3p l\u1EC7.");
          reply({ ok: true, data: await login(message.apiUrl, message.email, message.password) });
          break;
        case "AUTH_LOGOUT":
          await logout();
          reply({ ok: true });
          break;
        case "CAPTURE_START":
          if (!Number.isInteger(message.tabId) || message.tabId <= 0) throw new Error("Kh\xF4ng t\xECm th\u1EA5y tab video c\u1EA7n capture.");
          if (!await chrome.offscreen.hasDocument()) await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["USER_MEDIA"], justification: "Nh\u1EADn d\u1EA1ng ph\u1EE5 \u0111\u1EC1 t\u1EEB \xE2m thanh tab theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." });
          {
            const tabId = message.tabId;
            const result = await chrome.runtime.sendMessage({ type: "CAPTURE_START", streamId: await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }) });
            if (result.ok) capturedTabId = tabId;
            reply(result);
          }
          break;
        case "CAPTURE_STOP":
          reply(await stopCapture());
          break;
        case "DUE_CARDS":
          reply({ ok: true, data: await dueCards() });
          break;
        case "REVIEW_WORD":
          if (!bounded(message.word, 100) || ![1, 2, 3, 4].includes(message.rating)) throw new Error("\u0110\xE1nh gi\xE1 FSRS kh\xF4ng h\u1EE3p l\u1EC7.");
          reply({ ok: true, data: await reviewWord(message.word, message.rating) });
          break;
        case "SAVE_WORD":
          if (!bounded(message.word, 100) || !bounded(message.meaning, 1e3) || typeof message.context !== "string" || message.context.length > 4e3 || !PLATFORMS.has(message.platform ?? "") || message.videoId !== null && (typeof message.videoId !== "string" || message.videoId.length > 128) || message.timestamp !== null && (typeof message.timestamp !== "number" || !Number.isFinite(message.timestamp) || message.timestamp < 0)) throw new Error("D\u1EEF li\u1EC7u t\u1EEB v\u1EF1ng kh\xF4ng h\u1EE3p l\u1EC7.");
          reply({ ok: true, data: await saveWord(message) });
          break;
        default:
          throw new Error("Message kh\xF4ng \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3.");
      }
    } catch (error) {
      reply({ ok: false, error: error instanceof Error ? error.message : "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh." });
    }
  })();
  return true;
});
