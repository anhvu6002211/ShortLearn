"use strict";
(() => {
  // src/offscreen/index.ts
  var stream = null;
  var context = null;
  async function start(streamId) {
    await stop();
    stream = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } }, video: false });
    stream.getAudioTracks().forEach((track) => {
      track.onended = () => {
        void chrome.runtime.sendMessage({ type: "CAPTURE_ENDED" });
      };
    });
    context = new AudioContext();
    const source = context.createMediaStreamSource(stream);
    source.connect(context.destination);
  }
  async function stop() {
    stream?.getTracks().forEach((track) => track.stop());
    stream = null;
    if (context) {
      await context.close();
      context = null;
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    void (async () => {
      try {
        if (message.type === "CAPTURE_START" && message.streamId) await start(message.streamId);
        else if (message.type === "CAPTURE_STOP") await stop();
        else return;
        reply({ ok: true });
      } catch (error) {
        reply({ ok: false, error: error instanceof Error ? error.message : "Kh\xF4ng th\u1EC3 capture tab." });
      }
    })();
    return true;
  });
})();
