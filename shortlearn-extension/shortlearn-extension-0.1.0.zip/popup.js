"use strict";
(() => {
  // src/popup/index.ts
  var app = document.querySelector("#app");
  function captureControls() {
    const box = document.createElement("section"), start = document.createElement("button"), stop = document.createElement("button"), status = document.createElement("p");
    start.textContent = "B\u1EAFt \u0111\u1EA7u AI Live Captions";
    stop.textContent = "D\u1EEBng capture";
    stop.style.background = "#334155";
    status.id = "capture-status";
    start.onclick = async () => {
      start.disabled = true;
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const result = await chrome.runtime.sendMessage({ type: "CAPTURE_START", tabId: tab?.id });
      status.textContent = result.ok ? "\u0110ang capture \xE2m thanh tab; ch\u01B0a b\u1EADt STT." : result.error || "Kh\xF4ng th\u1EC3 capture.";
      start.disabled = false;
    };
    stop.onclick = async () => {
      const result = await chrome.runtime.sendMessage({ type: "CAPTURE_STOP" });
      status.textContent = result.ok ? "\u0110\xE3 d\u1EEBng v\xE0 gi\u1EA3i ph\xF3ng audio." : result.error || "Kh\xF4ng th\u1EC3 d\u1EEBng.";
    };
    box.append(start, stop, status);
    return box;
  }
  async function reviewControls() {
    const box = document.createElement("section"), title = document.createElement("h2"), status = document.createElement("p");
    title.textContent = "\xD4n t\u1EADp FSRS";
    status.setAttribute("role", "status");
    box.append(title, status);
    const result = await chrome.runtime.sendMessage({ type: "DUE_CARDS" });
    if (!result.ok) {
      status.textContent = result.error || "Kh\xF4ng t\u1EA3i \u0111\u01B0\u1EE3c th\u1EBB.";
      return box;
    }
    const card = Array.isArray(result.data) ? result.data[0] : null;
    if (!card) {
      status.textContent = "Kh\xF4ng c\xF3 th\u1EBB \u0111\u1EBFn h\u1EA1n.";
      return box;
    }
    const word = document.createElement("strong"), meaning = document.createElement("p"), ratings = document.createElement("div");
    word.textContent = card.word;
    meaning.textContent = card.meaning;
    ratings.className = "ratings";
    ["L\u1EA1i", "Kh\xF3", "T\u1ED1t", "D\u1EC5"].forEach((label, index) => {
      const button = document.createElement("button");
      button.textContent = label;
      button.onclick = async () => {
        ratings.querySelectorAll("button").forEach((item) => item.setAttribute("disabled", ""));
        const rated = await chrome.runtime.sendMessage({ type: "REVIEW_WORD", word: card.word, rating: index + 1 });
        status.textContent = rated.ok ? "\u0110\xE3 c\u1EADp nh\u1EADt l\u1ECBch FSRS." : rated.error || "Kh\xF4ng th\u1EC3 ch\u1EA5m th\u1EBB.";
        if (rated.ok) setTimeout(() => void render(), 400);
      };
      ratings.append(button);
    });
    box.append(word, meaning, ratings);
    return box;
  }
  async function render() {
    const state = await chrome.runtime.sendMessage({ type: "AUTH_STATUS" });
    app.replaceChildren();
    if (state.ok && state.data) {
      const p = document.createElement("p");
      p.textContent = `\u0110\xE3 \u0111\u0103ng nh\u1EADp: ${state.data.user.email}`;
      const b = document.createElement("button");
      b.textContent = "\u0110\u0103ng xu\u1EA5t";
      b.onclick = async () => {
        await chrome.runtime.sendMessage({ type: "AUTH_LOGOUT" });
        void render();
      };
      app.append(p, b, await reviewControls(), captureControls());
      return;
    }
    const form = document.createElement("form");
    form.id = "login";
    form.innerHTML = '<label>API URL<input name="api" type="url" value="http://127.0.0.1:5000" required></label><label>Email<input name="email" type="email" required></label><label>M\u1EADt kh\u1EA9u<input name="password" type="password" required></label><button>\u0110\u0103ng nh\u1EADp</button><p id="message" role="status"></p>';
    form.onsubmit = async (event) => {
      event.preventDefault();
      const d = new FormData(form);
      const r = await chrome.runtime.sendMessage({ type: "AUTH_LOGIN", apiUrl: d.get("api"), email: d.get("email"), password: d.get("password") });
      if (r.ok) void render();
      else form.querySelector("#message").textContent = r.error || "\u0110\u0103ng nh\u1EADp th\u1EA5t b\u1EA1i.";
    };
    app.append(form, captureControls());
  }
  void render();
})();
