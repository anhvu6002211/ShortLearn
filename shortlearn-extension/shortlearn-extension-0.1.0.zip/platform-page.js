"use strict";
(() => {
  // src/content/platform.ts
  function platformFromHost(host = location.hostname) {
    if (host.endsWith("youtube.com")) return "youtube";
    if (host.endsWith("tiktok.com")) return "tiktok";
    if (host.endsWith("instagram.com")) return "instagram";
    return null;
  }
  function platformVideoId(platform2, url = location.href) {
    const u = new URL(url);
    if (platform2 === "youtube") return u.pathname.match(/^\/shorts\/([\w-]{11})/)?.[1] ?? (u.pathname === "/watch" && /^[\w-]{11}$/.test(u.searchParams.get("v") ?? "") ? u.searchParams.get("v") : null);
    if (platform2 === "tiktok") return u.pathname.match(/\/video\/(\d+)/)?.[1] ?? null;
    if (platform2 === "instagram") return u.pathname.match(/^\/reels?\/([\w-]+)/)?.[1] ?? null;
    return null;
  }
  var SELECTORS = { tiktok: ['[data-e2e="video-captions"]', '[class*="DivCaption"]'], instagram: ['[aria-label*="caption" i] span[dir="auto"]', '[aria-label*="subtitle" i] span[dir="auto"]'] };
  function readPlatformCaption(platform2) {
    for (const selector of SELECTORS[platform2]) {
      const values = Array.from(document.querySelectorAll(selector)).filter((n) => n.getClientRects().length).map((n) => (n.textContent ?? "").replace(/\s+/g, " ").trim()).filter((t) => t.length > 1 && t.length < 500 && !/^\d[\d,.]*$/.test(t));
      if (values.length) return values.at(-1);
    }
    return "";
  }

  // src/content/platformPage.ts
  var SOURCE = "shortlearn-page";
  var platform = platformFromHost();
  var lastUrl = "";
  var lastText = "";
  var scheduled = false;
  var generation = 0;
  var fallbackSent = false;
  function emit(type, payload = {}) {
    window.postMessage({ source: SOURCE, type, ...payload }, location.origin);
  }
  function scan() {
    scheduled = false;
    if (!platform || platform === "youtube") return;
    const videoId = platformVideoId(platform);
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      lastText = "";
      fallbackSent = false;
      const current = ++generation;
      emit("VIDEO", { platform, videoId });
      setTimeout(() => {
        if (current === generation && !lastText) emit("NO_CAPTION", { platform, videoId });
      }, 5e3);
    }
    const text = readPlatformCaption(platform);
    if (text && text !== lastText) {
      lastText = text;
      emit("CAPTION", { text, time: document.querySelector("video")?.currentTime ?? 0, platform, videoId });
    } else if (!text && !fallbackSent) {
      fallbackSent = true;
      emit("FALLBACK", { platform, videoId });
    }
  }
  var observer = new MutationObserver(() => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(scan);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  scan();
})();
