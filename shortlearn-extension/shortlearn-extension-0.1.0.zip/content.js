"use strict";
(() => {
  // src/shared/subtitles.ts
  function cueAt(cues2, time) {
    let low = 0, high = cues2.length - 1;
    while (low <= high) {
      const mid = low + high >> 1;
      const cue = cues2[mid];
      if (time >= cue.start && time <= cue.start + cue.duration) return cue;
      if (time < cue.start) high = mid - 1;
      else low = mid + 1;
    }
    return null;
  }

  // src/services/translation/index.ts
  var CACHE_LIMIT = 150;
  var CONCURRENCY_LIMIT = 3;
  var cache = /* @__PURE__ */ new Map();
  var pending = /* @__PURE__ */ new Map();
  var queue = [];
  var running = 0;
  async function withSlot(work) {
    if (running >= CONCURRENCY_LIMIT) await new Promise((resolve) => queue.push(resolve));
    running += 1;
    try {
      return await work();
    } finally {
      running -= 1;
      queue.shift()?.();
    }
  }
  async function translateEnglish(text) {
    const source = text.trim();
    if (!source) return "";
    const hit = cache.get(source);
    if (hit) return hit;
    const active = pending.get(source);
    if (active) return active;
    const task = withSlot(async () => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8e3);
      try {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=vi&dt=t&q=${encodeURIComponent(source)}`;
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error("Ch\u01B0a th\u1EC3 d\u1ECBch.");
        const payload = await response.json();
        const value = Array.isArray(payload?.[0]) ? payload[0].map((s) => typeof s?.[0] === "string" ? s[0] : "").join("").trim() : "";
        if (!value || value.toLocaleLowerCase() === source.toLocaleLowerCase()) throw new Error("Ch\u01B0a th\u1EC3 d\u1ECBch.");
        if (cache.size >= CACHE_LIMIT) cache.delete(cache.keys().next().value);
        cache.set(source, value);
        return value;
      } finally {
        clearTimeout(timer);
      }
    });
    pending.set(source, task);
    try {
      return await task;
    } finally {
      pending.delete(source);
    }
  }

  // src/content/overlay/overlay.ts
  var HOST_ID = "shortlearn-extension-overlay";
  var CaptionOverlay = class {
    constructor(onWord, onSave) {
      this.onWord = onWord;
      this.onSave = onSave;
      this.host.id = HOST_ID;
      this.host.style.cssText = "all:initial;position:fixed;z-index:2147483647;left:50%;bottom:12%;transform:translateX(-50%);pointer-events:none;max-width:min(760px,90vw)";
      const root = this.host.attachShadow({ mode: "open" }), style = document.createElement("style"), box = document.createElement("section");
      style.textContent = ".box{font:600 22px/1.35 system-ui,sans-serif;color:#fff;text-align:center;background:rgba(7,10,18,.86);backdrop-filter:blur(12px);padding:10px 18px;border:1px solid rgba(255,255,255,.16);border-radius:14px;text-shadow:0 1px 3px #000;pointer-events:auto}.en button{all:unset;cursor:pointer;border-radius:4px}.en button:focus-visible,.en button:hover{color:#f8d477;outline:2px solid #f8d477}.vi{font:500 17px/1.35 system-ui;color:#f8d477;margin-top:4px}.status,.lookup span{font:500 12px system-ui;color:#cbd5e1;margin-top:6px}.lookup{display:none;gap:6px;align-items:center;margin-top:10px}.lookup.open{display:flex}.lookup input{min-width:180px;padding:7px;border:1px solid #64748b;border-radius:6px;background:#111827;color:#fff}.lookup button{padding:7px 10px;border:0;border-radius:6px;background:#f8d477;color:#111827;font-weight:700}";
      box.className = "box";
      box.setAttribute("aria-live", "polite");
      this.english.className = "en";
      this.vietnamese.className = "vi";
      this.status.className = "status";
      this.lookup.className = "lookup";
      this.meaning.setAttribute("aria-label", "Ngh\u0129a ti\u1EBFng Vi\u1EC7t");
      this.save.type = "submit";
      this.save.textContent = "L\u01B0u t\u1EEB";
      this.lookup.append(this.word, this.meaning, this.save, this.lookupStatus);
      this.lookup.onsubmit = (event) => {
        event.preventDefault();
        const meaning = this.meaning.value.trim();
        if (!meaning) return;
        this.save.disabled = true;
        void this.onSave(this.word.textContent ?? "", meaning).then(() => {
          this.lookupStatus.textContent = "\u0110\xE3 l\u01B0u v\xE0o ShortLearn.";
        }).catch((error) => {
          this.lookupStatus.textContent = error instanceof Error ? error.message : "Kh\xF4ng th\u1EC3 l\u01B0u t\u1EEB.";
        }).finally(() => {
          this.save.disabled = false;
        });
      };
      box.append(this.english, this.vietnamese, this.status, this.lookup);
      root.append(style, box);
    }
    onWord;
    onSave;
    host = document.createElement("div");
    english = document.createElement("div");
    vietnamese = document.createElement("div");
    status = document.createElement("div");
    lookup = document.createElement("form");
    word = document.createElement("strong");
    meaning = document.createElement("input");
    save = document.createElement("button");
    lookupStatus = document.createElement("span");
    mount() {
      if (!document.getElementById(HOST_ID)) document.documentElement.append(this.host);
    }
    show(text, translation = "") {
      this.english.replaceChildren();
      for (const part of text.split(/(\s+)/)) {
        const word = part.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’-]+$/gu, "");
        if (word) {
          const b = document.createElement("button");
          b.type = "button";
          b.textContent = part;
          b.onclick = () => {
            this.word.textContent = word;
            this.meaning.value = "";
            this.lookupStatus.textContent = "\u0110ang tra\u2026";
            this.lookup.classList.add("open");
            void this.onWord(word).then((value) => {
              this.meaning.value = value;
              this.lookupStatus.textContent = "";
              this.meaning.focus();
            }).catch(() => {
              this.lookupStatus.textContent = "Kh\xF4ng tra \u0111\u01B0\u1EE3c t\u1EF1 \u0111\u1ED9ng; nh\u1EADp ngh\u0129a th\u1EE7 c\xF4ng.";
              this.meaning.focus();
            });
          };
          this.english.append(b);
        } else this.english.append(document.createTextNode(part));
      }
      this.vietnamese.textContent = translation;
      this.status.textContent = "";
    }
    setTranslation(text) {
      this.vietnamese.textContent = text;
    }
    setStatus(text) {
      this.english.textContent = "";
      this.vietnamese.textContent = "";
      this.status.textContent = text;
    }
    remove() {
      this.host.remove();
    }
  };

  // src/content/index.ts
  var cues = [];
  var video = null;
  var currentText = "";
  var currentVideoId = null;
  var currentPlatform = "youtube";
  var translationGeneration = 0;
  var overlay = new CaptionOverlay((word) => translateEnglish(word), async (word, meaning) => {
    const result = await chrome.runtime.sendMessage({ type: "SAVE_WORD", word, meaning, context: currentText, platform: currentPlatform, videoId: currentVideoId, timestamp: video?.currentTime ?? null });
    if (!result.ok) throw new Error(result.error || "Kh\xF4ng th\u1EC3 l\u01B0u t\u1EEB.");
  });
  function show(text) {
    if (!text || text === currentText) return;
    currentText = text;
    const generation = ++translationGeneration;
    overlay.show(text);
    void translateEnglish(text).then((value) => {
      if (generation === translationGeneration) overlay.setTranslation(value);
    }).catch(() => {
    });
  }
  function render() {
    if (!video || !cues.length) return;
    show(cueAt(cues, video.currentTime)?.text ?? "");
  }
  function bindVideo() {
    const next = document.querySelector("video");
    if (next === video) return;
    video?.removeEventListener("timeupdate", render);
    video = next;
    video?.addEventListener("timeupdate", render, { passive: true });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== "shortlearn-page") return;
    bindVideo();
    overlay.mount();
    switch (event.data.type) {
      case "VIDEO":
        currentVideoId = typeof event.data.videoId === "string" ? event.data.videoId : null;
        currentPlatform = ["youtube", "tiktok", "instagram"].includes(event.data.platform) ? event.data.platform : location.hostname.includes("tiktok") ? "tiktok" : location.hostname.includes("instagram") ? "instagram" : "youtube";
        cues = [];
        currentText = "";
        overlay.setStatus("ShortLearn \u0111ang t\xECm ph\u1EE5 \u0111\u1EC1 ti\u1EBFng Anh\u2026");
        break;
      case "CUES":
        if (Array.isArray(event.data.cues)) cues = event.data.cues;
        render();
        break;
      case "CAPTION":
        if (!cues.length && typeof event.data.text === "string") show(event.data.text);
        break;
      case "FALLBACK":
        overlay.setStatus("\u0110ang \u0111\u1ECDc ph\u1EE5 \u0111\u1EC1 tr\u1EF1c ti\u1EBFp t\u1EEB tr\xECnh ph\xE1t\u2026");
        break;
      case "NO_CAPTION":
        if (!currentText) overlay.setStatus("Video n\xE0y kh\xF4ng c\xF3 ph\u1EE5 \u0111\u1EC1 ti\u1EBFng Anh kh\u1EA3 d\u1EE5ng.");
        break;
      case "UNSUPPORTED":
        overlay.remove();
        break;
    }
  });
})();
